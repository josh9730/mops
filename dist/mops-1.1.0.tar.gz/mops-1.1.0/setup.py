# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mops', 'mops.tests', 'mops.utils']

package_data = \
{'': ['*'], 'mops': ['defaults/*', 'renderers/*']}

install_requires = \
['DateTime>=4.4,<5.0',
 'Jinja2>=3.0.3,<4.0.0',
 'PyYAML>=6.0,<7.0',
 'atlassian-python-api>=3.20.1,<4.0.0',
 'google-api-core>=2.6.0,<3.0.0',
 'google-api-python-client>=2.39.0,<3.0.0',
 'google-auth-httplib2>=0.1.0,<0.2.0',
 'google-auth-oauthlib>=0.5.0,<0.6.0',
 'google-auth>=2.6.0,<3.0.0',
 'googleapis-common-protos>=1.55.0,<2.0.0',
 'keyring>=23.5.0,<24.0.0',
 'pydantic>=1.9.0,<2.0.0',
 'typer>=0.4.0,<0.5.0']

setup_kwargs = {
    'name': 'mops',
    'version': '1.1.0',
    'description': 'MOP and Change Doc creation helper.',
    'long_description': None,
    'author': 'josh-work',
    'author_email': 'jdickman@cenic.org',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
